package com.lab8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ps15054TranGiaKhangLab8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
