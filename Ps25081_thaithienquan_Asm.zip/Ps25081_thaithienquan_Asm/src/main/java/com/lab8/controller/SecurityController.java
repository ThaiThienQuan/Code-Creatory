package com.lab8.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lab8.entity.Account;
import com.lab8.repository.AccountRepository;

@Controller
public class SecurityController {
	@Autowired
	AccountRepository dao;
	@RequestMapping("/security/login/form")
	public String loginForm(Model model) {
		model.addAttribute("message","Vui lòng đăng nhập");
		return "security/login";
	}
	@RequestMapping("/security/signup/form")
	public String signupForm(Model model) {
		Account Account = new Account();
		model.addAttribute("Account", Account);
		List<Account> Accounts = dao.findAll();
		model.addAttribute("Accounts", Accounts);
		model.addAttribute("message","Vui lòng đăng nhập");
		return "security/signup";
	}
	@RequestMapping("/security/signup/form/create")
	public String create(Model model,Account Account) {
		// thêm 1 danh mục mới vào bảng categories
		dao.save(Account);
		return "redirect:/security/signup/form";
	}
	
	@RequestMapping("/security/login/success")
	public String loginSuccess(Model model) {
		model.addAttribute("message","Đăng nhập thành công");
		return "security/login";
	}
	
	@RequestMapping("/security/login/error")
	public String loginError(Model model) {
		model.addAttribute("message","Sai thông tin đăng nhập!");
		return "security/login";
	}
	
	@RequestMapping("/security/unauthoried")
	public String unauthoried(Model model) {
		model.addAttribute("message","Không có quyền truy vấn~");
		return "security/login";
	}
	
	@RequestMapping("/security/logoff/success")
	public String logoffSuccess(Model model) {
		model.addAttribute("message","Bạn đã đăng xuất");
		return "security/login";
	}
	

}
