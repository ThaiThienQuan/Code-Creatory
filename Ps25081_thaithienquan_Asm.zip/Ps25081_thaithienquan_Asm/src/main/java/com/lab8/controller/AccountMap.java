package com.lab8.controller;
import java.util.HashMap;

import com.lab8.entity.Account;

public class AccountMap extends HashMap<String, Account> {

}