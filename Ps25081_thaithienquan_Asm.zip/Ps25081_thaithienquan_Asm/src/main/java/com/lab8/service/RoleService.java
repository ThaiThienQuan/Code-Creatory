package com.lab8.service;

import java.util.List;

import com.lab8.entity.Role;

public interface RoleService {

	public List<Role> getAll();

}
